package com.online_store1.online_store1.Entities;
import java.util.List;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name ="Store")
public class Store {
	public Long getStoreId() {
		return StoreId;
	}
	public void setStoreId(Long storeId) {
		StoreId = storeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private Long StoreId;	
	public List<Product> getProduct() {
		return product;
	}
	public void setProduct(List<Product> product) {
		this.product = product;
	}
	private String name;
	private String address;
	
	@OneToMany(mappedBy="store")
	List<Product>product;
	

}
