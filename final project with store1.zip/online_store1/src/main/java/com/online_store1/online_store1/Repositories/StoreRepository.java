package com.online_store1.online_store1.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.online_store1.online_store1.Entities.Store;

public interface StoreRepository extends JpaRepository<Store,Long> {

}
