 package com.online_store1.online_store1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineStore1Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineStore1Application.class, args);
	}
}

