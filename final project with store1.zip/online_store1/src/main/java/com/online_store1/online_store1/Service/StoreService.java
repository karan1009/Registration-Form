package com.online_store1.online_store1.Service;

import java.util.List;

import com.online_store1.online_store1.Entities.Store;

public interface StoreService {

	Store createStore(Store store);
	
//STEP 2 FETCHING
List<Store>getAll();
}
