package com.online_store1.online_store1.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online_store1.online_store1.Entities.Store;
import com.online_store1.online_store1.Repositories.StoreRepository;
import com.online_store1.online_store1.Service.StoreService;

@Service
public class StoreServiceImpl implements StoreService {

	@Autowired
	StoreRepository storeRepository;
	@Override
	public Store createStore(Store store) {
		return storeRepository.save(store);
		
	}
	@Override
	public List<Store> getAll() {
		return storeRepository.findAll();
	}
	

}
