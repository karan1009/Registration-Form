package com.online_store1.online_store1.Entities;

public class ProductException extends Exception{

	public ProductException(String Str)
	{
		super(Str);
	}
}

